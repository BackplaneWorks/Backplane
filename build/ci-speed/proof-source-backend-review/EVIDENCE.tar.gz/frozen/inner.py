"""Closed experiment executor: one pinned source checker, under the real guard."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

LAB = Path(__file__).resolve().parent
ROOT = LAB.parents[2]
CAP = 3699998720


def main():
    phase = sys.argv[1]
    assert phase in ('negative', 'positive') and len(sys.argv) == 2
    assert os.environ.get('BACKPLANE_HEAVY_BOAT_SANDBOX') == '1'
    assert os.environ.get('BACKPLANE_HEAVY_OFFLOADED') == '1'
    out = ROOT/'build/ci-packet/proof-source-backend'/phase
    out.mkdir(parents=True, exist_ok=True)
    rel = Path('/proc/self/cgroup').read_text().split('0::', 1)[1].strip().lstrip('/')
    cg = Path('/sys/fs/cgroup')/rel
    assert int((cg/'memory.max').read_text()) == CAP and (cg/'memory.swap.max').read_text().strip() == '0'
    spec = importlib.util.spec_from_file_location('proof_native_guard', LAB/'source/scripts/heavy-guard.py')
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    assert guard.verify_shard_cgroup() and guard.admit('proof-shard'), 'real native resource admission refused'
    lock = guard.lock_path().open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    os.environ[guard.FD_VAR] = str(lock.fileno())
    assert guard.inherited_lock(guard.lock_path()) == lock.fileno()
    resource.setrlimit(resource.RLIMIT_STACK, (1024**3, resource.getrlimit(resource.RLIMIT_STACK)[1]))
    bun = ROOT/'build/proof-source-tools/bun'
    assert hashlib.sha256(bun.read_bytes()).hexdigest() == '795b37d736a88d746b0e8bb5fcde92bf29bd0f9ac6a1dd1a950fd37440cf5822'
    entry = LAB/'negative.bend' if phase == 'negative' else LAB/'source/build/proof-shards/plan_cur/000/PROOF.bend'
    command = [str(bun), str(LAB/'compiler/bend2/main.ts'), str(entry), '--check-only']
    def stats():
        return {'memory_max_bytes': int((cg/'memory.max').read_text()),
                'swap_max': int((cg/'memory.swap.max').read_text()),
                'memory_current_bytes': int((cg/'memory.current').read_text()),
                'memory_peak_bytes': int((cg/'memory.peak').read_text()),
                'events': {k: int(v) for k, v in (l.split() for l in (cg/'memory.events').read_text().splitlines())}}
    before = stats()
    (out/'RESOURCE-CAP.json').write_text(json.dumps({'cgroup': rel, 'pid': os.getpid(),
        'pid_start': Path('/proc/self/stat').read_text().split(') ')[1].split()[19],
        'actual_bend_flock_held': True, 'lock_inode': os.fstat(lock.fileno()).st_ino,
        'guard_admitted': True, 'command': command, **before}, indent=2)+'\n')
    start = time.monotonic()
    with (out/'checker.log').open('w') as output:
        result = subprocess.run(['/usr/bin/time', '-v', '-o', str(out/'checker.time'), *command],
                                cwd=LAB/'source', stdout=output, stderr=subprocess.STDOUT,
                                pass_fds=(lock.fileno(),))
    final = {'phase': phase, 'checker_exit': result.returncode, 'seconds': time.monotonic()-start,
             'command': command, 'before': before, 'after': stats(),
             'actual_bend_flock_held': guard.inherited_lock(guard.lock_path()) == lock.fileno()}
    (out/'EXECUTION.json').write_text(json.dumps(final, sort_keys=True, indent=2)+'\n')
    return result.returncode


if __name__ == '__main__':
    sys.exit(main())
