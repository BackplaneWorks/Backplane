"""One approved canonical proof-shard experiment; no app/emit or full proof gate."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

ROOT = Path.cwd()
LAB = ROOT/'build/ci-speed/proof-source-backend'
OUT = ROOT/'build/ci-packet/proof-source-backend'
CONTROLLER = 536870912
COMPILER = 3699998720
BUN_PIN = '795b37d736a88d746b0e8bb5fcde92bf29bd0f9ac6a1dd1a950fd37440cf5822'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(65536), b''):
            h.update(block)
    return h.hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    assert os.environ.get('BACKPLANE_HEAVY_BOAT_SANDBOX') == '1'
    assert os.environ.get('BACKPLANE_HEAVY_OFFLOADED') == '1'
    rel = Path('/proc/self/cgroup').read_text().split('0::', 1)[1].strip().lstrip('/')
    cg = Path('/sys/fs/cgroup')/rel
    unit = cg.name
    assert unit.startswith('ascii-cmd-') and unit.endswith('.scope')
    subprocess.run(['systemctl', '--user', '--no-ask-password', 'set-property', '--runtime',
                    unit, 'MemoryMax='+str(CONTROLLER), 'MemorySwapMax=0'], check=True)
    assert int((cg/'memory.max').read_text()) == CONTROLLER and (cg/'memory.swap.max').read_text().strip() == '0'
    controller_events = lambda: {k: int(v) for k, v in
        (line.split() for line in (cg/'memory.events').read_text().splitlines())}
    controller_before = controller_events()
    assert not OUT.exists(), 'existing attempt: inspect it; never repeat a proof from this driver'
    OUT.mkdir(parents=True)
    identity = json.loads((LAB/'IDENTITY.json').read_text())
    identity_sha = sha(LAB/'IDENTITY.json')
    ps = load(LAB/'source/scripts/proof-shards.py', 'canonical_worker_plan')
    def verify():
        assert sha(LAB/'IDENTITY.json') == identity_sha
        names = {p.relative_to(LAB).as_posix() for p in LAB.rglob('*') if p.is_file()}
        assert names == set(identity['files']) | {'IDENTITY.json'}
        for name, before in identity['files'].items():
            p = LAB/name
            assert not p.is_symlink() and sha(p) == before['sha256'] and ps.portable_mode(p) == before['mode'], name
        assert sha(LAB/'source/build/proof-shards/plan_cur/manifest.json') == identity['canonical_manifest_sha256']
        ps.verify(LAB/'source', LAB/'source/build/proof-shards/plan_cur')
    verify()
    tools = ROOT/'build/proof-source-tools'
    tools.mkdir(exist_ok=True)
    bun = tools/'bun'
    available = shutil.which('bun')
    if available is not None and sha(available) == BUN_PIN:
        shutil.copyfile(available, bun)
    else:
        archive = tools/'bun.zip'
        with urllib.request.urlopen('https://github.com/oven-sh/bun/releases/download/bun-v1.3.10/bun-linux-x64-baseline.zip', timeout=45) as src, archive.open('wb') as dst:
            shutil.copyfileobj(src, dst)
        assert sha(archive) == '41201a8c5ee74a9dcbb1ce25a1104f1f929838b57a845aa78d98379b0ce7cde2'
        with zipfile.ZipFile(archive) as z:
            bun.write_bytes(z.read('bun-linux-x64-baseline/bun'))
        archive.unlink()
    bun.chmod(0o755)
    assert sha(bun) == BUN_PIN
    env = {**os.environ, 'BEND_NO_TELEMETRY': '1', 'DO_NOT_TRACK': '1',
           'BUN_CONFIG_NO_ANALYTICS': '1', 'BP_BEND_MODULES': '1', 'BP_BEND_PAGED': '1',
           'BP_BEND_COMPACT': '0', 'BP_BEND_EVENT_BATCH': '128', 'BP_BEND_SOURCE_BODIES': '1',
           'BP_MODULE_BASELINE_CHECKER_SHA256': identity['compiler_files']['bend2/bend.ts'],
           'BUN_JSC_forceRAMSize': str(1024**3), 'BUN_JSC_maxPerThreadStackUsage': str(512*1024**2),
           'BUN_JSC_numberOfGCMarkers': '1', 'BUN_JSC_numberOfDFGCompilerThreads': '1',
           'BUN_JSC_numberOfFTLCompilerThreads': '1'}
    recorded_env = {k: env[k] for k in ('BEND_NO_TELEMETRY', 'DO_NOT_TRACK', 'BUN_CONFIG_NO_ANALYTICS',
        'BP_BEND_MODULES', 'BP_BEND_PAGED', 'BP_BEND_COMPACT', 'BP_BEND_EVENT_BATCH', 'BP_BEND_SOURCE_BODIES',
        'BP_MODULE_BASELINE_CHECKER_SHA256', 'BUN_JSC_forceRAMSize', 'BUN_JSC_maxPerThreadStackUsage',
        'BUN_JSC_numberOfGCMarkers', 'BUN_JSC_numberOfDFGCompilerThreads', 'BUN_JSC_numberOfFTLCompilerThreads')}
    rows = []
    success = False
    try:
        for phase, timeout in [('negative', 45), ('positive', 1000)]:
            verify()
            out = OUT/phase
            out.mkdir()
            spill = ROOT/'build/proof-source-spill'/phase
            spill.mkdir(parents=True)
            filesystem = subprocess.check_output(['stat', '-f', '-c', '%T', str(spill)], text=True).strip()
            assert filesystem not in ('tmpfs', 'ramfs'), 'spill must be disk-backed'
            child_unit = 'bp-proof-source-'+phase+'-'+str(os.getpid())+'.scope'
            stop = threading.Event()
            started = time.monotonic()
            def sample():
                with (out/'memory-stat.jsonl').open('w') as f:
                    while not stop.wait(0.1):
                        try:
                            cap = json.loads((out/'RESOURCE-CAP.json').read_text())
                            at = Path('/sys/fs/cgroup')/cap['cgroup']
                            stat = dict(line.split() for line in (at/'memory.stat').read_text().splitlines())
                            events = {k: int(v) for k, v in (line.split() for line in (at/'memory.events').read_text().splitlines())}
                            f.write(json.dumps({'seconds': time.monotonic()-started,
                                'current': int((at/'memory.current').read_text()), 'peak': int((at/'memory.peak').read_text()),
                                'anon': int(stat['anon']), 'file': int(stat['file']), 'events': events})+'\n')
                            f.flush()
                        except (OSError, ValueError, KeyError):
                            pass
            thread = threading.Thread(target=sample, daemon=True)
            thread.start()
            timed_out = False
            with (out/'unit.log').open('w') as log:
                try:
                    result = subprocess.run(['systemd-run', '--user', '--scope', '--quiet', '--unit='+child_unit,
                        '-p', 'MemoryMax=3700000000', '-p', 'MemorySwapMax=0', '--',
                        sys.executable, '-IB', str(LAB/'inner.py'), phase],
                        env={**env, 'TMPDIR': str(spill), 'BP_COMPILER_PROFILE': str(out/'profile.jsonl')},
                        stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    subprocess.run(['systemctl', '--user', 'stop', child_unit], capture_output=True, timeout=15)
                    result = subprocess.CompletedProcess([], 124)
            stop.set()
            thread.join(timeout=2)
            unit_result = subprocess.run(['systemctl', '--user', 'show', child_unit, '-p', 'Result',
                '-p', 'MemoryPeak', '-p', 'MemoryMax', '-p', 'MemorySwapMax', '-p', 'ActiveState'], capture_output=True, text=True)
            (out/'unit-result.txt').write_text(unit_result.stdout+unit_result.stderr)
            execution = json.loads((out/'EXECUTION.json').read_text()) if (out/'EXECUTION.json').exists() else None
            text = (out/'checker.log').read_text() if (out/'checker.log').exists() else ''
            accepted = execution is not None and ps.verdict(execution['checker_exit'], text)
            row = {'phase': phase, 'seconds': time.monotonic()-started, 'timed_out': timed_out,
                   'unit_exit': result.returncode, 'unit_result': unit_result.stdout,
                   'spill_filesystem': filesystem,
                   'execution': execution, 'checker_policy_accepted': accepted,
                   'log_sha256': sha(out/'checker.log') if (out/'checker.log').exists() else None}
            rows.append(row)
            (out/'RESULT.json').write_text(json.dumps(row, sort_keys=True, indent=2)+'\n')
            assert not timed_out and execution is not None and 'oom-kill' not in unit_result.stdout, 'failed/OOM/missing execution receipt; no qualification'
            assert execution['actual_bend_flock_held']
            timed = (out/'checker.time').read_text()
            peak = re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)', timed)
            exit_status = re.search(r'Exit status:\s*(\d+)', timed)
            assert peak and exit_status and int(exit_status[1]) == execution['checker_exit']
            row['peak_rss_kib'] = int(peak[1])
            for state in ('before', 'after'):
                assert execution[state]['memory_max_bytes'] == COMPILER and execution[state]['swap_max'] == 0
                assert execution[state]['events'].get('oom', 0) == execution[state]['events'].get('oom_kill', 0) == 0
            if phase == 'negative':
                assert not accepted and execution['checker_exit'] != 0
                assert 'Location: bad' in text and '- expected :' in text and "expected : ':'" not in text, 'negative must fail at the typed proof body'
                row['false_theorem_rejected'] = True
            else:
                assert accepted, 'real checker verdict failed'
                complete, fallback, names = [], [], set()
                proof_file = str(LAB/'source/build/proof-shards/plan_cur/000/PROOF.bend')
                active = None
                with (out/'profile.jsonl').open() as f:
                    for line in f:
                        mark = json.loads(line)
                        if mark['phase'] == 'module:check:start':
                            active = mark['file']
                        elif mark['phase'] == 'module:check:end':
                            active = None
                        if active == proof_file and mark['phase'] == 'events:before-check':
                            names.update(mark.get('names', []))
                        if mark['phase'] == 'modules:complete':
                            complete.append(mark)
                        if mark['phase'] == 'modules:fallback':
                            fallback.append(mark)
                expected = set(identity['original_block_hashes']['PROOF.bend'])
                row['checked_proof_names'] = sorted(names)
                row['expected_proof_names'] = sorted(expected)
                row['modules_complete'] = complete
                assert complete and not fallback and all(m['discard_results'] is True for m in complete)
                assert expected <= names, 'not every original proof definition has a checked-event receipt'
            verify()
            assert sha(bun) == BUN_PIN
            row['inputs_tools_unchanged'] = True
            (out/'RESULT.json').write_text(json.dumps(row, sort_keys=True, indent=2)+'\n')
            print(json.dumps({k: v for k, v in row.items() if k not in ('execution', 'unit_result', 'modules_complete')}), flush=True)
        assert controller_events().get('oom', 0) == controller_events().get('oom_kill', 0) == 0
        success = True
    finally:
        summary = {'kind': 'one canonical shard via frozen PR856 source checker', 'state': 'passed' if success else 'failed',
            'identity_sha256': identity_sha, 'canonical_manifest_sha256': identity['canonical_manifest_sha256'],
            'shard': '000', 'primary_laws': identity['primary_laws'], 'command_results': rows,
            'controller_memory_max_bytes': int((cg/'memory.max').read_text()), 'controller_swap_max': int((cg/'memory.swap.max').read_text()),
            'controller_peak_bytes': int((cg/'memory.peak').read_text()), 'combined_hard_cap_bytes': COMPILER+CONTROLLER,
            'controller_events_before': controller_before, 'controller_events_after': controller_events(),
            'bun_sha256': sha(bun), 'compiler_files': identity['compiler_files'], 'environment': recorded_env,
            'full_proof_qualified': False, 'release_qualified': False,
            'limits': 'One unsliced canonical shard only; historical native OOM has different inputs/cap, not a matched baseline'}
        (OUT/'SUMMARY.json').write_text(json.dumps(summary, sort_keys=True, indent=2)+'\n')
        print(json.dumps({'state': summary['state'], 'shard': '000', 'primary_laws': len(identity['primary_laws']),
                          'combined_hard_cap_bytes': summary['combined_hard_cap_bytes']}), flush=True)
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(main())
