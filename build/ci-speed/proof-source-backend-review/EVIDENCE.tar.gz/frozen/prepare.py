"""Freeze one existing unsliced canonical shard and the exact PR856 checker."""
import hashlib
import importlib.util
import io
import json
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path

ROOT = Path.cwd()
LAB = ROOT/'build/ci-speed/proof-source-backend'
ORIGINAL = Path('/home/h/Documents/i2cjak/backplane-bend/.backplane/worktrees/backplane-c9843d68')
PLAN = ORIGINAL/'build/proof-shards/plan_cur'
PIN = '37e080c1c51fcd2505c5ce77e9c8929bbac2fc3d4d4a359d120625b61c821891'
COMMIT = 'fd932a32c3e2b1a305de7141c4beaec219443893'
UPSTREAM = Path('/home/h/Documents/i2cjak/bend-memory-1261555')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load(p, name):
    spec = importlib.util.spec_from_file_location(name, p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    assert not (LAB/'source').exists(), 'frozen source already exists; inspect it, do not overwrite'
    assert sha(PLAN/'manifest.json') == PIN
    ps = load(ORIGINAL/'scripts/proof-shards.py', 'canonical_plan')
    manifest = ps.verify(ORIGINAL, PLAN)
    shard = next(s for s in manifest['shards'] if 'watch_copy_intent_none' in s['primary_laws'])
    assert shard['id'] == '000' and len(shard['primary_laws']) == 25
    cc = load(ROOT/'scripts/content-cache.py', 'canonical_closure')
    actual = cc.Tree(ORIGINAL).closure('build/proof-shards/plan_cur/000/PROOF.bend')
    assert 'PROOF.bend' not in actual and 'LAWS.bend' not in actual, 'never pull the full canonical proof into this experiment'
    block_hashes = {}
    for origin in ('LAWS.bend', 'PROOF.bend'):
        orig_imports, orig_blocks = ps.parse((ORIGINAL/origin).read_text(), origin)
        imports, blocks = ps.parse((PLAN/'000'/origin).read_text(), origin)
        selected = {name for at, name in shard['declarations'] if at == origin}
        expected = [b for b in orig_blocks if b['name'] in selected]
        assert blocks == expected, 'law/proof blocks differ from originals'
        for alias, target in imports.items():
            if target == 'Base':
                assert orig_imports[alias] == 'Base'
            elif origin == 'PROOF.bend' and alias == 'Laws':
                assert target == './LAWS.bend'
            else:
                assert (PLAN/'000'/target).resolve() == (ORIGINAL/orig_imports[alias]).resolve()
        block_hashes[origin] = {b['name']: hashlib.sha256(b['text'].encode()).hexdigest() for b in blocks}
    source = LAB/'source'
    for name, digest in manifest['sources'].items():
        assert sha(ORIGINAL/name) == digest
        dest = source/name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ORIGINAL/name, dest)
    for name in ('proof-shards.py', 'bend-closure.py', 'ci-packet.py', 'laws-shape.py', 'bendok.sh', 'heavy-guard.py'):
        dest = source/'scripts'/name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ORIGINAL/'scripts'/name, dest)
    planned = source/'build/proof-shards/plan_cur'
    planned.mkdir(parents=True)
    shutil.copy2(PLAN/'manifest.json', planned/'manifest.json')
    for item in manifest['shards']:
        for name, digest in item['files'].items():
            assert sha(PLAN/name) == digest
            dest = planned/name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(PLAN/name, dest)
    meta = subprocess.check_output(['git', 'show', COMMIT+':patches/bend-module-check-experiment.json'], cwd=ROOT)
    patch = subprocess.check_output(['git', 'show', COMMIT+':patches/bend-module-check-experiment.patch'], cwd=ROOT)
    metadata = json.loads(meta)
    assert hashlib.sha256(patch).hexdigest() == metadata['patch_sha256'] == '4405d272062f81d713743aab104af0c5943888b65dfd33d124b66492f7340d12'
    (LAB/'CHECKER.json').write_bytes(meta)
    (LAB/'CHECKER.patch').write_bytes(patch)
    archive = subprocess.check_output(['git', 'archive', metadata['upstream_commit'], 'bend2'], cwd=UPSTREAM)
    with tempfile.TemporaryDirectory(prefix='bp-frozen856-') as temp:
        temp = Path(temp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
            tar.extractall(temp, filter='data')
        pp = temp/'checker.patch'
        pp.write_bytes(patch)
        subprocess.run(['git', 'apply', '--check', str(pp)], cwd=temp, check=True)
        subprocess.run(['git', 'apply', str(pp)], cwd=temp, check=True)
        for name, digest in metadata['patched_sha256'].items():
            assert sha(temp/name) == digest, name
        shutil.copytree(temp/'bend2', LAB/'compiler/bend2')
    (LAB/'negative.bend').write_text('import Base\ndef bad() -> {0n == 1n : Nat}:\n  {==}\n')
    inventory = {}
    for p in sorted(LAB.rglob('*')):
        if p.is_file():
            assert not p.is_symlink()
            inventory[p.relative_to(LAB).as_posix()] = {'sha256': sha(p), 'mode': ps.portable_mode(p)}
    identity = {'schema': 1, 'scope': 'ONE original canonical shard plus isolated typed false-theorem control; no full proof/emit',
                'checker_commit': COMMIT, 'checker_metadata_sha256': sha(LAB/'CHECKER.json'),
                'patch_sha256': metadata['patch_sha256'], 'compiler_files': metadata['patched_sha256'],
                'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ORIGINAL, text=True).strip(),
                'canonical_manifest_sha256': PIN, 'shard': shard['id'], 'primary_laws': shard['primary_laws'],
                'original_block_hashes': block_hashes, 'actual_input_count': len(actual),
                'actual_input_bytes': sum((ORIGINAL/n).stat().st_size for n in actual),
                'files': inventory, 'native_baseline': 'Historical looser-cap OOM only; deleted single-law inputs; no matched baseline/speed claim'}
    (LAB/'IDENTITY.json').write_text(json.dumps(identity, sort_keys=True, indent=2)+'\n')
    print(json.dumps({'shard': '000', 'primary_laws': 25, 'actual_inputs': len(actual),
                      'actual_bytes': identity['actual_input_bytes'], 'identity_sha256': sha(LAB/'IDENTITY.json'),
                      'compiler_patch_sha256': metadata['patch_sha256']}))


if __name__ == '__main__':
    main()
