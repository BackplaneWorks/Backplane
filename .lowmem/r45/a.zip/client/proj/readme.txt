rig fixture
